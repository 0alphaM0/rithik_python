n=int(input("enter a number"))
sum=0
temp=n
while temp!=0:
        d=temp%10
        sum=sum+(d**3)
        temp=temp//10
if n==sum:
        print("armstrong yes")
else:
        print("not a armstrong")
