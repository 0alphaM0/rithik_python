a=int(input("enter a number"))
temp=a
sum=0
while temp!=0:
        d=temp%10
        sum=(sum*10)+d
        temp=temp//10
if sum==a:
        print("it is a palindrome number")
else:
        print("not a palindrome")

