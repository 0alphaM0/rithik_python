a=int(input("enter a number"))
if (a%2)==0:
    print("even")
else:print("odd")
