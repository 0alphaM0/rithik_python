a="python"
b="java"
print(a,b)
c=a
a=b
b=c
print(a,b)
